import Home from './Home'
export default function Category() {
    return <Home />
}